// import React, { useState } from 'react';
// import logo from './logo.svg';
// import './App.css';

// const GrandChild = (props)=>{
//   return(
//     <div>
//       <h1>
//         <Child val={props.val}/>
//       </h1>
//     </div>
//   )
// }

// const Child = (props)=>{
//   return(
//     <div>
//       <h1>{props.val}</h1>
//     </div>
//   )
// }

// function App() {

//   var [value] = useState({App:'App', Capp:'Capp'})

//   return (
//     <div >
//       {value.App = 'Cappp'}
//       {value.Capp = 'Sapp'}
//       <Child val={JSON.stringify(value)}/>
//       <GrandChild val={JSON.stringify(value)} />
//     </div>
//   );
// }
``
// export default App;












import React, {useState, Fragment} from 'react'

const ProviderContext = React.createContext()

const ConsumerContext = React.createContext()

const Provider = (props)=>{
  const [val, setVal] = useState('App')
  
  return(
    <ProviderContext.Provider value={val}>
      {props.children}
    </ProviderContext.Provider>
  )
}

const GrandChild = ()=>{
  return(
    <Fragment>
      <ProviderContext.Consumer>
        {
          (context)=>{
            return(
              <h1>
                {context}
              </h1>
            )
          }
        }
      </ProviderContext.Consumer>
    
    <Child />
    </Fragment>
  )
}

const Child = ()=>{
  return(
    <h1>
      <ProviderContext.Consumer>
        {
          (context)=>{
            return(
              <h1>
                {context}
              </h1>
            )
          }
        }
      </ProviderContext.Consumer>
    </h1>
  )
}

const App = ()=>{
  return(
    <Provider>
      <GrandChild />
    </Provider>
  )
}

export default App;