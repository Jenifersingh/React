import React from 'react'
import ReactDOM from 'react-dom'

import App from './ThemeTog/App'
// import App from './ThemeTogSingleFile/App'
// import App from './LearnReducer/App'
// import App from './LearnReducerSingleFile/App'
// import App from './LearnReducerFreely/App'
// import App from './EcommerceProj/App'
// import App from './FirebaseGitApp/App'
// import App from './EcommerceProjReducer/App'

ReactDOM.render(<App />, document.getElementById('root'))

