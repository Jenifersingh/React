import React, {useReducer} from 'react'
import {reducer} from './Context/reducer'
import {EComContext} from './Context/eComContext'
import { TodoContext } from '../LearnReducer/Context/Context'
import "bootstrap/dist/css/bootstrap.min.css"
import "react-toastify/dist/ReactToastify.css"
import { toast, ToastContainer } from 'react-toastify'
import BuySection from './Components/BuySection'
import {Container, Row, Col} from 'reactstrap'
import Cart from './Components/Cart'

const App = ()=>{

    const [product, dispatch] = useReducer(reducer, [])

    return (
        <EComContext.Provider value={{product, dispatch}}>
            {/* {console.log(product)} */}
            <Container>
                <ToastContainer/>
                <Row>
                    <Col md='8'>
                    <BuySection   />
                    </Col>
                    <Col md='4'>
                        <Cart  />
                    </Col>
                </Row>
            </Container>
        </EComContext.Provider>
    )
}

export default App;