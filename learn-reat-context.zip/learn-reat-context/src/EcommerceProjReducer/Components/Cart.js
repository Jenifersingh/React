import React, {useContext} from 'react'
import {Container, ListGroup, ListGroupItem, Button, Card, CardBody, CardHeader, CardFooter, Col, Row} from 'reactstrap'
import {EComContext} from '../Context/eComContext'
import {ADD_TO_CART, REMOVE_FROM_CART, PAY_HERE} from '../Context/action.types'
import { toast } from 'react-toastify'



const Cart = ()=>{

    
    const {product, dispatch} = useContext(EComContext)
    // console.log(product)
    

    let amount = 0

    product.forEach(item => {
        amount = parseFloat(amount) + parseFloat(item.productPrice)
    });

    return(
        <Container>
            <h1 className='text-success' >Your Cart</h1>
            <ListGroup>
                {product.map(item=>{
                    return(
                        <ListGroupItem key={item.id}>
                            <Row>
                                <Col>
                                    <img height={80} src={item.tinyImage} />
                                </Col>
                                <Col className='text-center'>
                                    <div className='text-primary'>
                                        {item.productName}
                                    </div>
                                    <span>price :- {item.productPrice}</span>
                                    <Button color='danger' 
                                    onClick={()=>{
                                        dispatch({
                                            type: REMOVE_FROM_CART,
                                            payload: item
                                        })
                                        toast("Removed from cart Successfully", {type: "warning"})
                                    }}>Remove</Button>
                                </Col>
                            </Row>
                        </ListGroupItem>

                    )

                })}
            </ListGroup>

            {
                product.length >= 1 ? (
                    <Card className='text-center mt-3'>
                        <CardHeader>Grand Total</CardHeader>
                        <CardBody>Your Amount for {product.length} product is {amount}</CardBody>
                        <CardFooter>
                            <Button color='success' onClick={()=>{
                                dispatch({
                                    type: PAY_HERE
                                })
                                toast("Payment was successfull", {type: "success"})
                            }}>Pay Here</Button>
                        </CardFooter>
                    </Card>
                ) : (
                    <h1 className='text-warning'>Cart is Empty</h1>
                )
            }
        </Container>
    )
}

export default Cart