import React, {useContext} from 'react'
import {Card, CardImg, CardBody, CardTitle, CardText} from 'reactstrap'
import {toast} from 'react-toastify'
import Button from 'reactstrap/lib/Button'
import {EComContext} from '../Context/eComContext'
import {ADD_TO_CART, REMOVE_FROM_CART, PAY_HERE} from '../Context/action.types'



const CartItem = ({products})=>{

    const {product, dispatch} = useContext(EComContext)

    return(
        <Card className='mt-2 mb-1'>
            <CardImg top height='250' width='100%' src={products.smallImage} />
                <CardBody className='text-center'>
                    <CardTitle>{products.productName}</CardTitle>
                    <CardText className='secondary'>Price: RS {products.productPrice}</CardText>
                    <Button color='success' 
                    onClick={()=>{
                        dispatch({
                            type: ADD_TO_CART,
                            payload: products
                        })
                        toast("Added to Cart Successfully", {type: "info"})
                    }}>Buy Now</Button>
                    
                </CardBody>
        </Card>
    )
}


export default CartItem