import {createContext} from 'react'

export const EComContext = createContext()