import {
     ADD_TO_CART,
     REMOVE_FROM_CART, 
     PAY_HERE, 
     ADD_TOTAL,
     SUB_TOTAL
    } from './action.types'

export const reducer = (state, action)=>{

    switch (action.type) {
        case ADD_TO_CART:
            return [...state, action.payload]

        case REMOVE_FROM_CART:
            return state.filter(s => s != action.payload)

        case PAY_HERE:
            return []

        // case ADD_TOTAL:
        //     return state + action.payload

        // case SUB_TOTAL:
        //     return state - action.payload
    
        default:
            break;
    }
}
