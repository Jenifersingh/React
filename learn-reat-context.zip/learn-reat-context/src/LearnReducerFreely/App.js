import React, { useReducer, createContext, useContext } from 'react'


const valueContext = createContext()


const Comp = ()=>{

    const { value, dispatch } = useContext(valueContext)

    dispatch({
        type: '2'
    })

    return(
        <h1>{value}</h1>
    )
}

const App = ()=>{

    const [value, dispatch] = useReducer( (state, action)=>{
        console.log(state)
        if(action.type == '1'){
            return 'type1'
        }
        if(action.type == '2'){
            return 'type2'
        }
        if(action.type == '3'){
            return 'type3'
        }
        return 'defaultType'
    } , 'NoN' )




    
    return(
        <valueContext.Provider value={{value, dispatch}}>
            {value}
            <Comp />
            {/* {value} */}
        </valueContext.Provider>
    )
}

export default App;