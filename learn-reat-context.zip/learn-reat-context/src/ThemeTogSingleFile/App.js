import React, {useContext, createContext, useState} from 'react'

const Context = createContext(['day',()=>{}])

const AppTheme = {
    day: {
        color: "#2C3335",
        backgroundColor: "#00CCCD",
        border: "2px solid black"
    },
    night: {
        color: "white",
        backgroundColor: "#758AA2",
        border: "2px dashed white"
    }
}



const HeroSection = ()=>{

    // const theme = useContext(Context)[0]
    // const currentTheme = AppTheme[theme]

    // console.log(theme)

    return(

        <Context.Consumer>
            {
                context=>{
                    const currentTheme = AppTheme[context[0]]
                    // console.log(context)
                    return(
                    <div
                    style={{
                        padding: '1rem',
                        background: `${currentTheme.backgroundColor}`,
                        color: `${currentTheme.color}`,
                        textAlign: 'center'
                    }}
                    >
                        <h1>Contect API Theme Toggler{context}</h1>
                    </div>
                    )
                }
            }
           
        </Context.Consumer>
    )
}

const ThemeToggler = ()=>{

    const [themeMode, setThemeMode] = useContext(Context)

    console.log(themeMode)

    return(
        <div
        onClick={()=>{setThemeMode(themeMode === 'day' ? 'night' : 'day')}}
        >
            <p>{themeMode === 'day' ? 'Its DAY' : 'Its NIGHT'}</p>
            
        </div>
    )
}



const Header = ()=>{
    return(
        <header>
            <h1>
                ThemeToggler
            </h1>
            <ThemeToggler />
        </header>
    )
}


const App = ()=>{

    const themeHook = useState('day')
    
    return(
        <Context.Provider value={themeHook}>
            <div>
                <Header />
                <HeroSection />
            </div>
        </Context.Provider>
        
    )
}



export default App