import React, {useContext, useState} from 'react'
import {
    Row,
    Conatainer,
    Col,
    Input,
    Button,
    InputGroup,
    InputGroupAddon
} from 'reactstrap'
import Axios from 'axios'

import UserCard from '../Components/UserCard'
import Repos from '../Components/Repos'
import {Redirect} from 'react-router-dom'
import {UserContext} from '../Context/UserContext'
import {toast} from 'react-toastify'
import Container from 'reactstrap/lib/Container'

const Home = ()=>{

    const context = useContext(UserContext)
    const [query, setQuery] = useState('')
    const [user, setUser] = useState(null)

    const fetchDetails = async ()=>{
        try{
            const {data} = await Axios.get(`https://api.github.com/users/${query}`)
            console.log(data)
            setUser(data)
        }
        catch(error){
            toast('Not Able to locate User', {type: 'error'})
        }
    }

    if(!context.user?.uid){
        return(
            <Redirect to='/SignIn' />
        )
    }

    return(
        <Container>
            <Row className='mt-3'>
                <Col md='5'>
                    <InputGroup>
                        <Input 
                        type='text'
                        value={query}
                        onChange={e => setQuery(e.target.value)}
                        placeholder='Put the username Here'
                        />
                        <InputGroupAddon addonType='append'>
                            <Button color='primary' onClick={fetchDetails}>
                                Fetch User
                            </Button>
                        </InputGroupAddon>
                    </InputGroup>
                    { user ? <UserCard user={user} /> : null}
                </Col>
                <Col md='7'>
                    {user ? <Repos repos_url={user.repos_url} /> : null}
                    {/* {console.log(user.repos_url) } */}
                </Col>
            </Row>
        </Container>
    )
}

export default Home;