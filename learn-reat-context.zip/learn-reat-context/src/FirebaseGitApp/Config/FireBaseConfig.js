export default {
    apiKey: "AIzaSyCRdLJlzmAYY34U8TLnffxPvgjorXs3p5I",
    authDomain: "hashinclude.firebaseapp.com",
    databaseURL: "https://hashinclude.firebaseio.com",
    projectId: "hashinclude",
    storageBucket: "hashinclude.appspot.com",
    messagingSenderId: "1092955109520",
    appId: "1:1092955109520:web:1f14ecfca80a4720770015",
    measurementId: "G-ENV0HVCH5C"
  };