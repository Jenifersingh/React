import React, {useState, useContext} from 'react'
import {
    Collapse,
    Navbar,
    NavbarBrand,
    Nav, NavItem, NavLink,NavbarText
} from 'reactstrap'
import {Link} from 'react-router-dom'


import {UserContext} from '../Context/UserContext'
import NavbarToggler from 'reactstrap/lib/NavbarToggler'

const Header = ()=>{

    const context = useContext(UserContext)

    const [isOpen, setIsOpen] = useState(false)

    const toggle = ()=> setIsOpen(!isOpen)

    // console.log(context)

    return(
        <Navbar color='info' light expand='md'>
            <NavbarBrand>
                <Link to='/' className='text-white'>
                    HASH INCLUDE APP
                </Link>
                
            </NavbarBrand>
            <NavbarText>
                {context.user?.email ? context.user?.email : ""}
            </NavbarText>
            <NavbarToggler onClick={toggle}/>
            <Collapse isOpen={isOpen} navbar>
                <Nav className='ml-auto' navbar>
                    
                    {
                        context.user ? (
                            <NavItem>
                                <NavLink tag={Link} onClick={()=>{context.setUser(null)}} className='text-white'>
                                    SignOut
                                </NavLink>
                            </NavItem>
                        ) : (
                            <>
                                <NavItem>
                                    <NavLink tag={Link} to='/SignUp' className='text-white'>
                                        SignUp
                                    </NavLink>
                                </NavItem>

                                <NavItem>
                                    <NavLink tag={Link} to='/SignIn' className='text-white'>
                                        SignIn
                                    </NavLink>
                                </NavItem>

                            </>
                        )
                    }
                    
                   
                </Nav>
            </Collapse>
        </Navbar>
    )
}

export default Header