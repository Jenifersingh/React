import React, {useContext} from 'react'
import Context from '../Context/Context'

import AppTheme from '../Colors'

const HeroSection = ()=>{
    const theme = useContext(Context)[0]
    const currentTheme = AppTheme[theme]

    return(
        <div
        style={{
            padding: '1rem',
            backgroundColor: `${currentTheme.backgroundColor}`,
            color: `${currentTheme.color}`,
            textAlign: 'center'
        }}
        >
            <h1>Context API Theme Toggler</h1>

        </div>
    )
}

export default HeroSection;