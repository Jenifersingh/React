import React, {useContext} from 'react'
import Context from '../Context/Context'

const ThemeToggler = ()=>{
    const [themeMode, setThemeMode] = useContext(Context)

    return(
        <div
        onClick={()=>{
            setThemeMode(themeMode === 'day' ? 'night' : 'day')
        }}
        >
            <p>{themeMode === 'day' ? 'Its DAY' : 'Its NIGHT'}</p>
        </div>
    )
}

export default ThemeToggler;