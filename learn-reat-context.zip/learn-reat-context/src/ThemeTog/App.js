import React, {useState} from 'react'
import Context from './Context/Context'
import Header from './Components/Header'
import HeroSection from './Components/HeroSection'
import ThemeToggler from './Components/ThemeToggler'

const App=()=>{
    const themeHook = useState('day')

    return(
        <Context.Provider value={themeHook}>
            <div>
                <Header />
                <HeroSection />
            </div>
        </Context.Provider>
    )
}


export default App;