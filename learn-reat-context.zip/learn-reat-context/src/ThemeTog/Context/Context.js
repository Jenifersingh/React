import {createContext} from 'react'

const Context = createContext(['day', ()=>{}])

export default Context;