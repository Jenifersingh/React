const AppTheme = {
    day: {
        color: "#2C3335",
        backgroundColor: "#00CCCD",
        border: "2px solid black"
    },
    night: {
        color: "white",
        backgroundColor: "#758AA2",
        border: "2px dashed white"
    }
}


export default AppTheme;