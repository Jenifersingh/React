import React, {useContext, createContext, useReducer, useState} from 'react'
import{
    FormGroup,
    Input,
    Button,
    Form,
    InputGroup,
    InputGroupAddon,
    Container,
    ListGroup,
    ListGroupItem
} from 'reactstrap'
import { v4 } from 'uuid';
import {FaCheckDouble} from 'react-icons/fa'



// action.types
const ADD_TODO = 'ADD_TODO'
const REMOVE_TODO = 'REMOVE_TODO'



//Context
const TodoContext = createContext()



//reducer
const todoReducer = (state, action)=>{
    switch (action.type) {
        case ADD_TODO:
            return [...state, action.payload]
    
        case REMOVE_TODO:
            return state.filter(todo => todo.id !== action.payload)

        default:
            return state
            
    }
}



//TodoForm
const TodoForm = ()=>{

    const [todoString, setTodoString] = useState('')
    const {dispatch} = useContext(TodoContext)

    const handleSubmit = e =>{
        e.preventDefault()
        if(todoString === ''){
            return alert('Please Enter a ToDo')
        }

        const todo = {
            todoString,
            id: v4()
        }

        dispatch({
            type: ADD_TODO,
            payload: todo
        })

        setTodoString('')
    }

    return(
        <Form onSubmit={handleSubmit} style={{top: '500px'}}>
            <FormGroup>
            <InputGroup>
                <Input
                type='text'
                name='todo'
                id='todo'
                placeholder='Your Next Todo'
                onChange={e => setTodoString(e.target.value)}
                value={todoString}
                />
                
                <InputGroupAddon addonType='prepend'>
                    <Button
                    color='warning'
                    >
                        Add
                    </Button>
                </InputGroupAddon>
            </InputGroup>
            </FormGroup>
            {todoString}
        </Form>
    )
}



//Todos
const Todos = ()=>{
    
    const {todos, dispatch} = useContext(TodoContext)

    return(
        <ListGroup className='mt-5 mb-2 items'>
            {
                todos.map(todo => {
                    return(
                        <ListGroupItem key={todo.id}>
                            {todo.todoString}
                            <span
                            style={{float: 'right'}}
                            onClick={
                                ()=>{
                                    dispatch({
                                        type: REMOVE_TODO,
                                        payload: todo.id
                                    })
                                }
                            }
                            >
                                <FaCheckDouble />
                            </span>
                        </ListGroupItem>
                    )
                })
            }
        </ListGroup>
    )
}





//App.js
const App = ()=>{
    
    const [todos, dispatch] = useReducer(todoReducer, [])

    return(
        <TodoContext.Provider value={{todos, dispatch}} >
            <Container fluid>
                <h1>Todo App With Context API</h1>
                <TodoForm />
                <Todos />
            </Container>
        </TodoContext.Provider>
    )
}

export default App;